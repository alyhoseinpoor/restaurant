# فرانت رستوران (React + Vite)

فرانتی که برای نمایش API جنگوی رستوران (منو، سفارش، کامنت، علاقه‌مندی) ساخته شده.
هدف این پروژه نمایش بک‌اند در رزومه‌ست، نه یک محصول کامل.

## اجرا

```bash
npm install
npm run dev
```

سپس روی `http://localhost:5173` باز می‌شه.

آدرس بک‌اند رو توی فایل `.env` تنظیم کن:

```
VITE_API_BASE_URL=http://127.0.0.1:8000
```

## تنظیمات لازم روی بک‌اند جنگو

### ۱. فعال کردن CORS
```bash
pip install django-cors-headers
```
توی `settings.py`:
```python
INSTALLED_APPS += ['corsheaders']
MIDDLEWARE.insert(0, 'corsheaders.middleware.CorsMiddleware')
CORS_ALLOWED_ORIGINS = ['http://localhost:5173']
```

### ۲. ساخت یک یوزر برای تست
چون endpoint ثبت‌نام عمومی وجود نداره، با یکی از این روش‌ها یوزر بساز:
```bash
python manage.py createsuperuser
```
یا از پنل ادمین جنگو یوزر معمولی بساز.

### ۳. تنظیم throttle scope (اختیاری)
`views.py` از `ScopedRateThrottle` با scope های `comment` و `order` استفاده می‌کنه.
اگه توی `settings.py` این‌ها رو تعریف نکرده باشی، ممکنه خطا بگیری:
```python
REST_FRAMEWORK = {
    ...
    'DEFAULT_THROTTLE_RATES': {
        'comment': '20/minute',
        'order': '30/minute',
    }
}
```

## چند نکته درباره رفتار API که فرانت باهاش هماهنگ شده

- **کامنت‌ها بعد از ثبت فوراً نمایش داده نمی‌شن** — چون `Comment.active` پیش‌فرض `False`
  هست و فقط کامنت‌های تأییدشده (از پنل ادمین) توی لیست میان.
- **کامنت‌ها بر اساس غذا فیلتر نمی‌شن سمت بک‌اند** — فرانت همه‌ی کامنت‌های
  تأییدشده رو می‌گیره و خودش بر اساس `food` فیلتر می‌کنه. برای پروژه واقعی
  بهتره یه `?food=<id>` به `get_queryset` اضافه کنی.
- **Order هم نقش سبد خرید و هم سفارش نهایی رو داره**: `active=False` یعنی
  توی سبد خریده، `active=True` یعنی نهایی شده. صفحه «سبد خرید» و «سفارش‌های
  نهایی» بر همین اساس جدا شدن.
- منو (`Food`, `Category`) توی بک‌اند permission عمومی داره، ولی فرانت فعلاً
  همه‌چیز رو پشت لاگین گذاشته چون بخش‌های دیگه (کامنت، سفارش) به هر حال نیاز
  به توکن دارن.

## ساختار پروژه

```
src/
  api.js              لایه ارتباط با API + مدیریت توکن JWT
  auth/AuthContext.jsx  وضعیت لاگین در کل اپ
  pages/              صفحات: Login, Menu, Cart, Orders, Favorites
  components/         Navbar, FoodCard, FoodModal, CategoryFilter
  styles.css          استایل کامل پروژه
```
